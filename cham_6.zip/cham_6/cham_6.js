//create a global variable
let capture;
let posterizeAmount = 2;
let tintcolor = 255;

/*create variable for reloading the camera
var reloadcam;*/

//create time call variables
var d = new Date();
var t = d.getTime();

//Get a stream of video from the user and store attach it to capture
//Setup is called once
function setup() {
    createCanvas(500,500);
    capture = createCapture(VIDEO);
    capture.size(500,500);
    capture.hide();
    filter(GRAY);

  select ('#Question2').hide();

  select ('#Question3').hide();

  select ('#Question4').hide();


  // blendMode(DIFFERENCE);

//setInterval(startCapture, 15000)

}
function startCapture() {
    navigator.mediaDevices.getUserMedia(constraints)
        .then(gotMedia)
        .catch(e => { console.error('getUserMedia() failed: ', e); });
}


function draw() {
    //pixels drawn on canvas using image function remains static and inverted(filter);
    tint(tintcolor);
    image(capture,0,0,500,500);
   // filter(INVERT);
    filter(POSTERIZE, posterizeAmount);
}

const constraints = { "video": { width: { max: 320 } } };
var canvas = document.getElementById('canvas');
var videoTrack;


function gotMedia(mediastream) {
    videoTrack = mediastream.getVideoTracks()[0];
    var imageCapture = new ImageCapture(videoTrack);
   mygrabFrame(imageCapture);
}

function mygrabFrame(imageCapture) {
    imageCapture.grabFrame()
        .then(processFrame)
        .catch(e => console.error('grabFrame() failed: ' + e));
}

function processFrame(imageBitmap) {
    canvas.width = imageBitmap.width;
    canvas.height = imageBitmap.height;
    canvas.getContext('2d').drawImage(imageBitmap, 0, 0);
    videoTrack.stop();
}

function invert() {
    var ctx = canvas.getContext('2d');
    var imageData = ctx.getImageData(0,0,canvas.width, canvas.height);
    var data = imageData.data;
    for (var i = 0; i < data.length; i += 4) {
        data[i]     = 255 - data[i];     // red
        data[i + 1] = 255 - data[i + 1]; // green
        data[i + 2] = 255 - data[i + 2]; // blue
    }
    ctx.putImageData(imageData, 0, 0);
}


function myFunction() {
    document.getElementById("demo").innerHTML = "Hello World";
}

function Q1Sanguine() {
 select ("#Question1").hide();
    select ("#Question2").show();
    tintcolor= "magenta";
    posterizeAmount +=2;
    console.log("Q1Sanguine");

}

function Q1Phlegmatic() {

select ("#Question1").hide();
select ("#Question2").show();
    tintcolor= "cyan";
    posterizeAmount +=2;
}

function Q2Choleric() {
    select ("#Question2").hide();
    select ("#Question3").show();
    tintcolor= "yellow";
    posterizeAmount +=2;
}

function Q2Sanguine() {
    select ("#Question2").hide();
    select ("#Question3").show();
    tintcolor= "magenta";
    posterizeAmount +=2;
}

function Q3Meloncholic() {
    select ("#Question3").hide();
    select ("#Question4").show();
    tintcolor= "gray";
    posterizeAmount +=2;
}


function Q3Choleric() {
    select ("#Question3").hide();
    select ("#Question4").show();
    tintcolor= "yellow";
    posterizeAmount +=3;
}

function Q4Phelgmatic() {
    select ("#Question4").hide();
    tintcolor= 255;
    posterizeAmount +=2;
}

function Q4Meloncholic() {
    select ("#Question4").hide();
    tintcolor= 255;
    posterizeAmount +=2;
}
